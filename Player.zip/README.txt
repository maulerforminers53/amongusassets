Sprites Extracted and Sorted by: JordanTRS
https://www.youtube.com/channel/UCGMsFdGMBgjm5zYMUohTLvg

To apply costumes, overlay the costume sprites on top of the default player sprites.